"""
Клиент для работы с Google Sheets API
"""
import os
import pickle
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from config import GOOGLE_SHEET_ID, GOOGLE_SHEET_NAME, GOOGLE_CREDENTIALS, STATUS_PUBLISHED

logger = logging.getLogger(__name__)

class GoogleSheetsClient:
    """Клиент для работы с Google Sheets API"""
    
    def __init__(self):
        self.service = None
        self.credentials = None
        self.TOKEN_FILE = 'token.json'
        self.SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
        self._authenticate()
    
    def _authenticate(self):
        """Аутентификация в Google Sheets API"""
        try:
            # Загружаем существующий токен
            if os.path.exists(self.TOKEN_FILE):
                try:
                    with open(self.TOKEN_FILE, 'rb') as token:
                        self.credentials = pickle.load(token)
                    logger.info("Загружен сохраненный токен аутентификации")
                except:
                    # Если не удалось загрузить как pickle, пробуем как JSON
                    import json
                    with open(self.TOKEN_FILE, 'r') as token:
                        token_data = json.load(token)
                        self.credentials = Credentials.from_authorized_user_info(token_data, self.SCOPES)
                    logger.info("Загружен токен из JSON файла")
            
            # Если нет валидных учетных данных, запрашиваем новые
            if not self.credentials or not self.credentials.valid:
                if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                    logger.info("Обновляем истекший токен...")
                    self.credentials.refresh(Request())
                    logger.info("Токен обновлен")
                else:
                    logger.info("Запрашиваем новые учетные данные...")
                    flow = InstalledAppFlow.from_client_config(
                        GOOGLE_CREDENTIALS, self.SCOPES
                    )
                    self.credentials = flow.run_local_server(port=0)
                    logger.info("Получены новые учетные данные")
                
                # Сохраняем токен для будущего использования
                with open(self.TOKEN_FILE, 'wb') as token:
                    pickle.dump(self.credentials, token)
                logger.info("Токен сохранен для будущего использования")
            
            # Создаем сервис
            self.service = build('sheets', 'v4', credentials=self.credentials)
            logger.info("Успешная аутентификация в Google Sheets API")
            
        except Exception as e:
            logger.error(f"Ошибка аутентификации: {e}")
            raise
    
    def get_pending_posts(self) -> List[Dict[str, Any]]:
        """
        Получает посты, готовые к публикации
        """
        try:
            # Получаем название первого листа
            sheet_metadata = self.service.spreadsheets().get(
                spreadsheetId=GOOGLE_SHEET_ID
            ).execute()
            sheets = sheet_metadata.get('sheets', [])
            if not sheets:
                logger.error("В таблице нет листов")
                return []
            
            first_sheet_name = sheets[0]['properties']['title']
            logger.info(f"Используем лист: {first_sheet_name}")
            
            # Получаем данные из таблицы (новая структура: 7 колонок)
            range_name = f"{first_sheet_name}!A:G"
            result = self.service.spreadsheets().values().get(
                spreadsheetId=GOOGLE_SHEET_ID,
                range=range_name
            ).execute()
            
            values = result.get('values', [])
            if not values:
                logger.info("Таблица пуста")
                return []
            
            headers = values[0]
            data_rows = values[1:]
            
            # Определяем индексы колонок
            col_indices = {}
            for i, header in enumerate(headers):
                if header == 'Дата':
                    col_indices['date'] = i
                elif header == 'Время':
                    col_indices['time'] = i
                elif header == 'Пост':
                    col_indices['text'] = i
                elif header == 'Изображение':
                    col_indices['image_urls'] = i
                elif header == 'Статус':
                    col_indices['status'] = i
            
            pending_posts = []
            current_time = datetime.now()
            
            logger.info(f"Ищем посты, время публикации которых наступило до {current_time.strftime('%H:%M')}")
            
            for row_index, row in enumerate(data_rows):
                try:
                    # Проверяем, что строка содержит все необходимые данные
                    if len(row) < 7:  # Новая структура: 7 колонок
                        continue
                    
                    # Получаем данные из строки (новая структура)
                    post_date_str = row[0] if len(row) > 0 else ""  # Дата
                    post_time_str = row[1] if len(row) > 1 else ""  # Время
                    post_text = row[2] if len(row) > 2 else ""      # Пост
                    midjourney_ru = row[3] if len(row) > 3 else ""  # Промпт RU
                    midjourney_en = row[4] if len(row) > 4 else ""  # Промпт EN
                    image_urls_str = row[5] if len(row) > 5 else "" # Изображение
                    status = row[6] if len(row) > 6 else ""         # Статус
                    
                    # Пропускаем заголовки таблицы
                    if post_date_str == "Дата" or post_time_str == "Время":
                        continue
                    
                    # Проверяем статус - пропускаем только опубликованные посты
                    if status and status.strip() == STATUS_PUBLISHED:
                        continue
                    
                    # Проверяем дату и время
                    if not post_date_str or not post_time_str:
                        continue
                    
                    try:
                        # Парсим дату и время с поддержкой разных форматов
                        date_str = post_date_str.strip()
                        time_str = post_time_str.strip()
                        
                        # Пробуем разные форматы даты
                        post_date = None
                        for date_format in ["%Y-%m-%d", "%d.%m.%y", "%d.%m.%Y", "%d/%m/%y", "%d/%m/%Y"]:
                            try:
                                post_date = datetime.strptime(date_str, date_format).date()
                                break
                            except ValueError:
                                continue
                        
                        if post_date is None:
                            logger.warning(f"Не удалось распарсить дату '{date_str}' в строке {row_index + 2}")
                            continue
                        
                        # Парсим время
                        post_time = datetime.strptime(time_str, "%H:%M").time()
                        post_datetime = datetime.combine(post_date, post_time)
                        
                        # Проверяем, что время публикации поста наступило
                        if post_datetime <= current_time:
                            # Обрабатываем ссылки на изображения
                            image_urls = []
                            if image_urls_str.strip():
                                # Проверяем, что это не ошибка, а реальный URL
                                if not any(error_word in image_urls_str.lower() for error_word in ['ошибка', 'error', 'failed', 'не удалось']):
                                    urls = [url.strip() for url in image_urls_str.split('\n') if url.strip()]
                                    # Фильтруем только валидные URL
                                    valid_urls = [url for url in urls if url.startswith(('http://', 'https://'))]
                                    image_urls = valid_urls[:10]  # Максимум 10 изображений
                            
                            pending_posts.append({
                                'row_index': row_index + 2,  # +2 потому что индексация с 0 и пропускаем заголовок
                                'date': post_date_str,
                                'time': post_time_str,
                                'text': post_text,
                                'image_urls': image_urls,
                                'status': status
                            })
                            
                            logger.info(f"Найден пост для публикации: {post_date_str} {post_time_str}")
                            
                    except ValueError as e:
                        logger.warning(f"Ошибка парсинга даты/времени в строке {row_index + 2}: {e}")
                        continue
                        
                except Exception as e:
                    logger.warning(f"Ошибка обработки строки {row_index + 2}: {e}")
                    continue
            
            logger.info(f"Найдено {len(pending_posts)} постов для публикации")
            return pending_posts
            
        except HttpError as e:
            logger.error(f"Ошибка Google Sheets API: {e}")
            raise
        except Exception as e:
            error_msg = str(e)
            if "Connection reset by peer" in error_msg or "Connection refused" in error_msg:
                logger.warning(f"Проблема с подключением к Google Sheets: {e}")
                logger.info("Попробуем переподключиться через 30 секунд...")
                return []
            else:
                logger.error(f"Неожиданная ошибка при получении данных: {e}")
                raise
    
    def update_post_status(self, row_index: int, status: str, error_message: str = None):
        """
        Обновляет статус поста в Google Sheets
        """
        try:
            # Получаем название первого листа
            sheet_metadata = self.service.spreadsheets().get(
                spreadsheetId=GOOGLE_SHEET_ID
            ).execute()
            sheets = sheet_metadata.get('sheets', [])
            if not sheets:
                logger.error("В таблице нет листов")
                return
            
            first_sheet_name = sheets[0]['properties']['title']
            
            # Обновляем статус в колонке G (7-я колонка)
            range_name = f"{first_sheet_name}!G{row_index}:H{row_index}"
            values = [[status, error_message or ""]]
            
            body = {
                'values': values
            }
            
            result = self.service.spreadsheets().values().update(
                spreadsheetId=GOOGLE_SHEET_ID,
                range=range_name,
                valueInputOption='RAW',
                body=body
            ).execute()
            
            logger.info(f"Статус поста в строке {row_index} обновлен на '{status}'")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка обновления статуса поста: {e}")
            return False
    
    def add_post(self, post_data: List[str]) -> bool:
        """
        Добавляет новый пост в Google Sheets
        """
        try:
            # Получаем название первого листа
            sheet_metadata = self.service.spreadsheets().get(
                spreadsheetId=GOOGLE_SHEET_ID
            ).execute()
            sheets = sheet_metadata.get('sheets', [])
            if not sheets:
                logger.error("В таблице нет листов")
                return False
            
            first_sheet_name = sheets[0]['properties']['title']
            logger.info(f"Используем лист: {first_sheet_name}")
            
            # Добавляем пост в конец таблицы
            range_name = f"{first_sheet_name}!A:G"
            body = {
                'values': [post_data]
            }
            
            result = self.service.spreadsheets().values().append(
                spreadsheetId=GOOGLE_SHEET_ID,
                range=range_name,
                valueInputOption='RAW',
                body=body
            ).execute()
            
            logger.info("Пост добавлен в таблицу")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка добавления поста: {e}")
            return False
    
    def get_all_posts(self) -> List[Dict[str, Any]]:
        """
        Получает все посты из таблицы
        """
        try:
            # Получаем название первого листа
            sheet_metadata = self.service.spreadsheets().get(
                spreadsheetId=GOOGLE_SHEET_ID
            ).execute()
            sheets = sheet_metadata.get('sheets', [])
            if not sheets:
                logger.error("В таблице нет листов")
                return []
            
            first_sheet_name = sheets[0]['properties']['title']
            logger.info(f"Используем лист: {first_sheet_name}")
            
            # Получаем данные из таблицы (новая структура: 7 колонок)
            range_name = f"{first_sheet_name}!A:G"
            result = self.service.spreadsheets().values().get(
                spreadsheetId=GOOGLE_SHEET_ID,
                range=range_name
            ).execute()
            
            values = result.get('values', [])
            if not values:
                logger.info("Таблица пуста")
                return []
            
            data_rows = values[1:]  # Пропускаем заголовок
            posts = []
            
            for row_index, row in enumerate(data_rows):
                try:
                    # Проверяем, что строка содержит все необходимые данные
                    if len(row) < 7:  # Новая структура: 7 колонок
                        continue
                    
                    # Получаем данные из строки (новая структура)
                    post_date_str = row[0] if len(row) > 0 else ""  # Дата
                    post_time_str = row[1] if len(row) > 1 else ""  # Время
                    post_text = row[2] if len(row) > 2 else ""      # Пост
                    midjourney_ru = row[3] if len(row) > 3 else ""  # Промпт RU
                    midjourney_en = row[4] if len(row) > 4 else ""  # Промпт EN
                    image_urls_str = row[5] if len(row) > 5 else "" # Изображение
                    status = row[6] if len(row) > 6 else ""         # Статус
                    
                    # Пропускаем заголовки таблицы
                    if post_date_str == "Дата" or post_time_str == "Время":
                        continue
                    
                    # Обрабатываем ссылки на изображения
                    image_urls = []
                    if image_urls_str.strip():
                        # Проверяем, что это не ошибка, а реальный URL
                        if not any(error_word in image_urls_str.lower() for error_word in ['ошибка', 'error', 'failed', 'не удалось']):
                            urls = [url.strip() for url in image_urls_str.split('\n') if url.strip()]
                            # Фильтруем только валидные URL
                            valid_urls = [url for url in urls if url.startswith(('http://', 'https://'))]
                            image_urls = valid_urls[:10]  # Максимум 10 изображений
                    
                    posts.append({
                        'row_index': row_index + 2,  # +2 потому что индексация с 0 и пропускаем заголовок
                        'date': post_date_str,
                        'time': post_time_str,
                        'text': post_text,
                        'image_urls': image_urls,
                        'status': status
                    })
                    
                except Exception as e:
                    logger.warning(f"Ошибка обработки строки {row_index + 2}: {e}")
                    continue
            
            logger.info(f"Найдено {len(posts)} постов в таблице")
            return posts
            
        except Exception as e:
            logger.error(f"Ошибка получения всех постов: {e}")
            return []
